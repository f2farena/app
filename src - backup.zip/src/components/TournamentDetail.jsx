import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

console.log('React version in TournamentDetail:', React.version);
console.log('useState exists:', !!useState);  // Check useState có tồn tại không
console.log('useEffect exists:', !!useEffect);  // Check useEffect (sẽ false nếu thiếu import)

// Trong handleConfirmRegistration (RegistrationModal):
const handleConfirmRegistration = async () => {
  try {
    const response = await fetch('http://localhost:8000/api/tournament-register/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: user.id, tournament_id: tournament.id, status: 0 })
    });
    const data = await response.json();
    console.log('Registration response:', data); // Log
    alert('Registration Confirmed!');
  } catch (error) {
    console.error('Error registering:', error);
  }
  onClose();
};

const RegistrationModal = ({ tournament, user, walletData, onClose, navigate }) => {
    // Logic kiểm tra
    const hasBrokerAccount = user.linkedBrokers.includes(tournament.broker);
    // Lấy số từ chuỗi ví dụ '1500.50 USDT' -> 1500.50
    const currentBalance = parseFloat(walletData.currentBalance); 
    const hasSufficientBalance = currentBalance >= tournament.minBalanceRequired;

    const handleOpenBrokerSite = () => {
        window.open(tournament.brokerRegistrationUrl, '_blank', 'noopener,noreferrer');
        onClose();
    };

    const handleGoToWallet = () => {
        navigate('/wallet');
        onClose();
    };
    
    const handleConfirmRegistration = () => {
        // Đây là nơi sẽ gọi API để đăng ký giải đấu thật
        console.log(`User ${user.id} confirmed registration for tournament ${tournament.id}`);
        alert('Registration Confirmed!'); // Thông báo tạm thời
        onClose();
    };

    const renderContent = () => {
        // Trường hợp 2: Chưa có tài khoản sàn
        if (!hasBrokerAccount) {
            return (
                <>
                    <h4>Account Required</h4>
                    <p>You need an account with <strong>{tournament.broker}</strong> to join this tournament.</p>
                    <p>Please register an account on their platform first.</p>
                    <div className="confirmation-buttons">
                        <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
                        <button className="btn btn-primary" onClick={handleOpenBrokerSite}>Register at {tournament.broker}</button>
                    </div>
                </>
            );
        }

        // Trường hợp 1: Có tài khoản nhưng không đủ số dư
        if (hasBrokerAccount && !hasSufficientBalance) {
            return (
                <>
                    <h4>Insufficient Balance</h4>
                    <p>Your current balance is <strong>{currentBalance.toFixed(2)} USDT</strong>, but this tournament requires a minimum of <strong>{tournament.minBalanceRequired} USDT</strong>.</p>
                    <p>Please deposit more funds to your wallet.</p>
                    <div className="confirmation-buttons">
                        <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
                        <button className="btn btn-primary" onClick={handleGoToWallet}>Go to Wallet</button>
                    </div>
                </>
            );
        }

        // Trường hợp 1: Đủ điều kiện
        if (hasBrokerAccount && hasSufficientBalance) {
            return (
                <>
                    <h4>Confirm Registration</h4>
                    <p>You are eligible to join the <strong>{tournament.title}</strong>.</p>
                    <div className="wallet-info-row" style={{padding: '0.5rem 0'}}>
                        <span className="label">Required Balance</span>
                        <span className="value">{tournament.minBalanceRequired} USDT</span>
                    </div>
                    <div className="wallet-info-row" style={{padding: '0.5rem 0'}}>
                        <span className="label">Your Current Balance</span>
                        <span className="value win">{currentBalance.toFixed(2)} USDT</span>
                    </div>
                    <p style={{marginTop: '1rem', color: 'var(--color-secondary-text)', fontSize: '0.9rem'}}>
                        By confirming, you agree to the tournament's terms and conditions.
                    </p>
                    <div className="confirmation-buttons">
                        <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
                        <button className="btn btn-accent" onClick={handleConfirmRegistration}>Confirm</button>
                    </div>
                </>
            );
        }

        return null; // Trường hợp mặc định
    };

    return (
        <>
            <div className="confirmation-overlay" onClick={onClose}></div>
            <div className="confirmation-modal card">
                {renderContent()}
            </div>
        </>
    );
};

const TournamentDetail = ({ user, walletData }) => {
  const { id } = useParams();

  useEffect(() => {  // Di chuyển toàn bộ khối useEffect từ top-level vào đây (giữ nguyên logic)
    const fetchTournamentDetail = async () => {
      try {
        const response = await fetch(`http://localhost:8000/api/tournaments/${id}`);
        const data = await response.json();
        console.log('Fetched tournament detail:', data); // Log
        setTournament({
          id: data.id,
          title: data.title,
          thumbnail: data.thumbnail,
          date: '2025-06-21', // Giữ hardcode hoặc thêm field
          author: 'PK Team',
          description: data.description,
          prizePool: data.prize_pool + ' USDT',
          participants: data.participants,
          symbol: data.symbol,
          startTime: data.event_time,
          broker: 'Go Markets', // Giả sử từ backend broker_name qua join
          minBalanceRequired: 500, // Đề xuất thêm field ở backend
          brokerRegistrationUrl: 'https://www.binance.com/en/register', // Thêm field url ở backend
          results: [], // Đề xuất endpoint /api/tournaments/{id}/results nếu cần
          images: [] // Đề xuất field images array ở backend
        });
      } catch (error) {
        console.error('Error fetching tournament detail:', error);
      }
    };

    fetchTournamentDetail();
  }, [id]);

  const navigate = useNavigate();
  const [tournament, setTournament] = useState(null);
  const [showRegisterModal, setShowRegisterModal] = useState(false);

  if (!tournament) {
    return (
      <div className="page-padding detail-page-container">
        <h2>Tournament Not Found</h2>
        <p>No tournament found with ID {id}.</p>
        <button className="btn btn-primary" onClick={() => navigate('/arena')}>
          Back to Arena
        </button>
      </div>
    );
  }

  const isTournamentEnded = new Date(tournament.startTime) < new Date();

  if (!user || !walletData) {
    return <div className="page-padding">Loading user data...</div>;
  }

  return (
    <div className="detail-page-container">
      <div style={{ position: 'relative' }}>
        <img
          src={tournament.thumbnail}
          alt={tournament.title}
          className="detail-page-banner"
          loading="lazy"
          onError={(e) => {
            console.error(`Failed to load image: ${tournament.thumbnail}`);
            e.target.src = 'https://placehold.co/500x220?text=Image+Not+Found';
          }}
          onLoad={(e) => console.log(`TournamentDetail image loaded: ${tournament.thumbnail}, size: ${e.target.naturalWidth}x${e.target.naturalHeight}`)}
        />
        <button
          className="icon-button detail-back-button"
          onClick={() => navigate('/arena')}
        >
          <svg fill="currentColor" viewBox="0 0 20 20">
            <path
              fillRule="evenodd"
              d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z"
              clipRule="evenodd"
            />
          </svg>
        </button>
      </div>

      <div className="page-padding">
        <h1 className="detail-page-title">{tournament.title}</h1>
        <p className="detail-page-meta">
          By {tournament.author} - {tournament.date}
        </p>

        <div className="card tournament-info-box">
          <div className="info-grid-item">
            <span className="info-label">Prize Pool</span>
            <span className="info-value accent">{tournament.prizePool}</span>
          </div>
          <div className="info-grid-item">
            <span className="info-label">Participants</span>
            <span className="info-value">{tournament.participants}</span>
          </div>
          <div className="info-grid-item">
            <span className="info-label">Symbol</span>
            <span className="info-value primary">{tournament.symbol}</span>
          </div>
          <div className="info-grid-item">
            <span className="info-label">Event Time</span>
            <span className="info-value">{new Date(tournament.startTime).toLocaleString()}</span>
          </div>
          <div className="info-grid-item">
            <span className="info-label">Broker</span>
            <span className="info-value">{tournament.broker}</span>
          </div>
        </div>

        <p className="detail-page-content">
          {tournament.description}
        </p>

        {isTournamentEnded && tournament.results.length > 0 && (
          <div className="card">
            <h2 className="section-title">Tournament Results</h2>
            <div className="leaderboard-table">
              <div className="leaderboard-header">
                <div>Rank</div>
                <div>Player</div>
                <div className="text-center">Score</div>
                <div className="text-right">Reward</div>
              </div>
              {tournament.results.map((result) => (
                <div
                  key={result.rank}
                  className={`leaderboard-row ${result.rank === 1 ? 'top-rank' : ''}`}
                >
                  <div className="leaderboard-rank">{result.rank}</div>
                  <div className="trader-info">
                    <span>{result.name}</span>
                  </div>
                  <div className="text-center">{result.score}</div>
                  <div className="text-right">{result.reward}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {!isTournamentEnded && (
        <footer className="detail-page-footer">
          <button 
            className="btn btn-accent" 
            style={{ width: '90%', maxWidth: '400px' }}
            onClick={() => setShowRegisterModal(true)}
          >
            Register Now
          </button>
        </footer>
      )}

      {showRegisterModal && (
        <RegistrationModal
            tournament={tournament}
            user={user}
            walletData={walletData}
            onClose={() => setShowRegisterModal(false)}
            navigate={navigate}
        />
      )}
    </div>
  );
};

export default TournamentDetail;